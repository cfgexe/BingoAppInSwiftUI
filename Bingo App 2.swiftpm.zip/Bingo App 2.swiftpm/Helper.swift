//
//  Helper.swift
//  NavigatinInSwiftUIStarter
//
//  Created by Andreas Schultz on 29.10.20.
//

import Foundation

enum Page {
    case page1
    case page2
    case page3
}
