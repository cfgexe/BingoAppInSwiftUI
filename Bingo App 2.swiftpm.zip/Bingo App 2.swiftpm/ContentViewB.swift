//File: ContentViewB.swift
//Project: NavigatinInSwiftUIStarter
//Created on 24.08.20
//Visit www.BLCKBIRDS.com for more tutorials.

import SwiftUI

struct ContentViewB: View {
    @Environment(\.colorScheme) var colorScheme: ColorScheme
    @State var buttonText = "Continue"
    @State private var hasTimeElapsed = false
    @EnvironmentObject var viewRouter: ViewRouter
    
    var body: some View {
        
        VStack {
            Image(systemName: "clock")
            Text(hasTimeElapsed ? "Loaded" : "Now loading...").onAppear(perform: delayText)
            if hasTimeElapsed {
                Button(action: {viewRouter.currentPage = .page2}) {
                    BackButtonContent()
                }
            }
        }.background(colorScheme == .light ? Color.white : Color.black)
    }
    private func delayText() {
        // Delay of 7.5 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            hasTimeElapsed = true
        }
    }
}

struct ContentViewB_Previews: PreviewProvider {

    static var previews: some View {
        ContentViewB().environmentObject(ViewRouter())
    }
}

struct BackButtonContent : View {
    var body: some View {
        Text("Continue")
            .foregroundColor(.white)
            .frame(width: 200, height: 50)
            .background(Color.blue)
            .cornerRadius(15)
            .padding(.top, 50)
    }
}
