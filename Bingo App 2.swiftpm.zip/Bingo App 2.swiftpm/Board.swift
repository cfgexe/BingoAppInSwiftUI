import SwiftUI
import Foundation

struct MyView: View {
    func genRand(loops:Int, min:Int, max:Int) -> Array<Int> {
        var list:Array<Int> = []
        var timesLooped:Int = 0
        while timesLooped != loops {
            var random1 = Int.random(in: 1...75)
            list.append(random1)
            timesLooped += 1
        }
        return list
    }
    var body: some View {
        let randGend = genRand(loops: 28, min: 1, max: 75).removeDuplicates(); let _ = print(randGend)
    }
}
extension Array where Element:Equatable {
    func genRand(loops:Int, min:Int, max:Int) -> Array<Int> {
        var list:Array<Int> = []
        var timesLooped:Int = 0
        while timesLooped != loops {
            var random1 = Int.random(in: 1...75)
            list.append(random1)
            timesLooped += 1
        }
        return list
    }
    func removeDuplicates() -> [Element] {
        var result = [Element]()
        
        for value in self {
            if result.contains(value) == false {
                result.append(value)
            }
        }
        return result
    }
}
